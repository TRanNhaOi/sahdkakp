package com.example.aicameraapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private ImageView imageView;
    private Spinner modeSpinner;
    private Bitmap capturedBitmap;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        modeSpinner = findViewById(R.id.modeSpinner);
        Button captureButton = findViewById(R.id.captureButton);
        Button processButton = findViewById(R.id.processButton);
        Button zoomButton = findViewById(R.id.zoomButton);

        // Khởi tạo Volley
        requestQueue = Volley.newRequestQueue(this);

        // Thiết lập Spinner với các chế độ
        String[] modes = {"Chân dung", "Phong cảnh", "Hoàng hôn", "Người", "Nhóm người", "Đen trắng", "Vintage", "HDR"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, modes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(adapter);

        // Chụp ảnh
        captureButton.setOnClickListener(v -> {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        });

        // Xử lý AI
        processButton.setOnClickListener(v -> {
            if (capturedBitmap != null) {
                String selectedMode = modeSpinner.getSelectedItem().toString();
                processImageWithAPI(capturedBitmap, selectedMode);
            }
        });

        // Zoom 80x và làm nét bằng AI
        zoomButton.setOnClickListener(v -> {
            if (capturedBitmap != null) {
                Bitmap zoomedBitmap = applyZoomAndAI(capturedBitmap);
                imageView.setImageBitmap(zoomedBitmap);
                saveImage(zoomedBitmap);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, Intent data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            capturedBitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(capturedBitmap);
        }
    }

    // Gọi API xử lý ảnh
    private void processImageWithAPI(Bitmap bitmap, String mode) {
        String apiUrl = "https://api.example.com/process-image"; // Thay bằng URL API thực tế (Pica AI/Fotor)
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, apiUrl, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Xử lý phản hồi từ API
                        Bitmap processedBitmap = applyLocalAIProcessing(bitmap, mode); // Fallback nếu API không trả về
                        imageView.setImageBitmap(processedBitmap);
                        saveImage(processedBitmap);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Nếu API lỗi, dùng xử lý cục bộ
                        Bitmap processedBitmap = applyLocalAIProcessing(bitmap, mode);
                        imageView.setImageBitmap(processedBitmap);
                        saveImage(processedBitmap);
                    }
                });
            requestQueue.add(jsonObjectRequest);
        } catch (Exception e) {
            // Fallback về xử lý cục bộ nếu có lỗi
            Bitmap processedBitmap = applyLocalAIProcessing(bitmap, mode);
            imageView.setImageBitmap(processedBitmap);
            saveImage(processedBitmap);
        }
    }

    // Xử lý AI cục bộ (fallback)
    private Bitmap applyLocalAIProcessing(Bitmap bitmap, String mode) {
        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        android.graphics.Canvas canvas = new android.graphics.Canvas(mutableBitmap);
        android.graphics.Paint paint = new android.graphics.Paint();
        ColorMatrix colorMatrix = new ColorMatrix();

        switch (mode) {
            case "Chân dung":
                colorMatrix.set(new float[] {
                    1.2f, 0, 0, 0, 20,
                    0, 1.2f, 0, 0, 20,
                    0, 0, 1.2f, 0, 20,
                    0, 0, 0, 1, 0
                });
                break;
            case "Phong cảnh":
                colorMatrix.set(new float[] {
                    1.5f, 0, 0, 0, 0,
                    0, 1.5f, 0, 0, 0,
                    0, 0, 1.5f, 0, 0,
                    0, 0, 0, 1, 0
                });
                break;
            case "Hoàng hôn":
                colorMatrix.set(new float[] {
                    1.5f, 0, 0, 0, 50,
                    0, 1.2f, 0, 0, 20,
                    0, 0, 1.0f, 0, 0,
                    0, 0, 0, 1, 0
                });
                break;
            case "Người":
                colorMatrix.set(new float[] {
                    1.3f, 0, 0, 0, 30,
                    0, 1.3f, 0, 0, 30,
                    0, 0, 1.3f, 0, 30,
                    0, 0, 0, 1, 0
                });
                break;
            case "Nhóm người":
                colorMatrix.set(new float[] {
                    1.4f, 0, 0, 0, 10,
                    0, 1.4f, 0, 0, 10,
                    0, 0, 1.4f, 0, 10,
                    0, 0, 0, 1, 0
                });
                break;
            case "Đen trắng":
                colorMatrix.setSaturation(0);
                break;
            case "Vintage":
                colorMatrix.set(new float[] {
                    1.0f, 0, 0, 0, 20,
                    0, 0.8f, 0, 0, 20,
                    0, 0, 0.6f, 0, 20,
                    0, 0, 0, 1, 0
                });
                break;
            case "HDR":
                colorMatrix.set(new float[] {
                    1.8f, 0, 0, 0, -10,
                    0, 1.8f, 0, 0, -10,
                    0, 0, 1.8f, 0, -10,
                    0, 0, 0, 1, 0
                });
                break;
        }

        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(mutableBitmap, 0, 0, paint);
        return mutableBitmap;
    }

    // Zoom 80x và làm nét bằng AI
    private Bitmap applyZoomAndAI(Bitmap bitmap) {
        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Matrix matrix = new Matrix();
        matrix.postScale(80.0f, 80.0f);
        Bitmap zoomedBitmap = Bitmap.createBitmap(mutableBitmap, 0, 0, mutableBitmap.getWidth(), mutableBitmap.getHeight(), matrix, true);

        android.graphics.Canvas canvas = new android.graphics.Canvas(zoomedBitmap);
        android.graphics.Paint paint = new android.graphics.Paint();
        ColorMatrix colorMatrix = new ColorMatrix();
        colorMatrix.set(new float[] {
            2.0f, 0, 0, 0, 0,
            0, 2.0f, 0, 0, 0,
            0, 0, 2.0f, 0, 0,
            0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(colorMatrix));
        canvas.drawBitmap(zoomedBitmap, 0, 0, paint);
        return zoomedBitmap;
    }

    // Lưu ảnh vào bộ nhớ
    private void saveImage(Bitmap bitmap) {
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile = new File(storageDir, "AI_Processed_" + System.currentTimeMillis() + ".jpg");
        try (FileOutputStream out = new FileOutputStream(imageFile)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}